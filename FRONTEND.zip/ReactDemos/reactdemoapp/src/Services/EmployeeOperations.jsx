import axios from "axios";

const Employee_API_URL="http://localhost:26924/api/Employees";

class EmployeeOperations
{
    getEmployees()
    {
        return axios.get(Employee_API_URL);
    }
    getEmployeeById(employeeId)
    {
        return axios.get(Employee_API_URL+'/'+employeeId);
    }
    createEmployee(employee)
    {
        return axios.post(Employee_API_URL,employee);
    }
    updateEmployee(employee,employeeId)
    {
        return axios.put(Employee_API_URL+'/'+employeeId,employee);
    }
    deleteEmployee(employeeId)
    {
        return axios.delete(Employee_API_URL+'/'+employeeId);
    }
}

export default new EmployeeOperations();
