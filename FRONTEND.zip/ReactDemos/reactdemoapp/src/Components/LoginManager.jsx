import {React} from "react";

//import Redirect from 'react-router-dom';

import { useState } from "react";

import axios from "axios";

import { Navigate } from "react-router-dom";

import DashBoard from "./DashBoard";

import AddLeave from "./LeaveCreate";

import LeaveListComponent from "./LeaveList";

 

export default function LoginManager() {

    // <Route path='/DashBoard' element={<DashBoard/>}></Route>

const [userName, setUserName] = useState("");

const [password, setPassword] = useState("");

const [data, setData] = useState("");

function validateForm() {

 

  return userName.length > 0 && password.length > 0;

 

}

 

//  const getResult =  () => {

//     return  axios.post('https://localhost:44346/api/Logins',

//     {"UserName":userName,"Password":password})

//        .then(res => {

//            console.log(res.data)

//            return res.data

//        })

//    }

async function handleSubmit(event){

console.log('handle submit called')

  event.preventDefault();

 

  if(event.target[0].value==="" && event.target[1].value==="")

  {alert("Enter Both User Name and Password")}

 

  else if (event.target[0].value==="")

  {alert("Enter User Name")}

 

  else if(event.target[1].value==="")

  {alert("Enter Password")}

 

  else

  {

   

 const result= await axios.post('http://localhost:26924/api/LoginManagers',

   {"UserName":userName,"Password":password})

   .then(res=> {

       console.log(res.data);

   return res.data;

   });

   // alert(result)

    if(result==="Login Success")

    {

     

         window.location = '/GetAllLeaveApp';

     

    }

    else{

       

        alert('invalid Credetials')

   

    }

}

}

return (

   

<div>

    <form onSubmit={handleSubmit}>

        <div className="col-sm-6 offset-sm-3">

            <label> Username</label>

            <input type="text" name="userName" value={userName}

             onChange={(e) =>setUserName(e.target.value)}            

            className="form-control"></input>

        </div>

        <div className="col-sm-6 offset-sm-3">

            <label> Password</label>

            <input type="text" name="password" value={password}

             onChange={(e) =>setPassword(e.target.value)}            

            className="form-control"></input>

        </div>

        <div>

            <button type="submit" className="btn btn-primary">Login</button>

            <button className="btn btn-danger">Cancel</button>

 

        </div>

    </form>

</div>

 

);

}