import React from 'react';

import "./Dashboard.css";

import { useNavigate,Redirect } from "react-router-dom";




const DashBoard = () => {

 let navigate = useNavigate();
//  if(sessionStorage.getItem('email')!==null){



 return (
   <div className='outerdivv'>

     <div className='outer-card'>

       <div  className='card-1'><h2 onClick={()=>navigate('/ListEmployee')}>My Details Section</h2></div>

       <div className='card-2'><h2 onClick={()=>navigate('/manager')}>My Manager Details Section</h2></div>

       <div className='card-3'><h2 onClick={()=>navigate('/leave')}>My Leave Application Section</h2></div>

       <div className='card-4'><h2 onClick={()=>navigate('/leave')}>My Reporting Employees'My Pending Leave Application Section</h2></div>
       {/* <div className='card-4'><h2 onClick={()=>navigate('/ShowLvDetailsById')}>ShowLvDetailsById</h2></div> */}
       <div className='card-4'><h2 onClick={()=>navigate('/Logout')}>Logout</h2></div>
     </div>

   </div>

 )

 }



export default DashBoard
