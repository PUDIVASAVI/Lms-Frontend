import React from 'react';
import ManagerOperations from '../Services/ManagerOperations';

class ListManager extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={
            employees:[]
        }
    }
    componentDidMount()
    {
        ManagerOperations.getEmployees().then((res)=>{
            this.setState({employees:res.data});
        })
    }
    render(){
        return(
            <div>
                <h1 className="text-center">Manager Details Section</h1>
                <br></br>
                <br></br>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.employees.map(
                                    emp=>
                                    <tr key={emp.managerId}>
                                        <td>{emp.managerId}</td>
                                        <td>{emp.managerName}</td>
                                        <td>{emp.managerEmailId}</td>
                                        <td>{emp.mobileNo}</td>
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}
export default ListManager;

