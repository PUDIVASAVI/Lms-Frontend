import React, { Component } from 'react' 
import axios from 'axios';



import { BrowserRouter,Routes,Route,Link,redirect, Router, Switch } from 'react-router-dom';

export default class  Registration extends Component {
    constructor(props)
    {
        super(props)
        this.state={
            employeeId:'',
             employeeName:'',
             employeeEmailId:'',
             mobileNo:'',
             password:'',
             conPassword:'',
             dateJoined:'',
             department:'',
             availableLeave:'',
             fields: {},
             errors:{}
        }
        this.handleChanghe=this.handleChange.bind(this);
        this.newemp=this.newemp.bind(this);
    }
handleChange(object)
{
    this.setState(object)
}       
newemp(){
    alert("Registration Successful");
        let url='http://localhost:34600/api/Employees';
            axios.post(url,{

                employeeId:this.state.employeeId,
                employeeName:this.state.employeeName,
                
                employeeEmailId:this.state.employeeEmailId,
                mobileNo:this.state.mobileNo,
                password:this.state.password,
                conPassword:this.state.conPassword,
                dateJoined:this.state.dateJoined,
                department:this.state.department,
                availableLeave:this.state.availableLeave
            }
            ).then(response=>{
              if(response.data.email!=null)
              {
                alert("Register successful");
                  sessionStorage.setItem("Email",response.data.employeeEmailId);
                  
                  window.location="/Login";
              }
              else
                  {
      
                      alert("Email ID is Invalid");
                  }
          }).catch(error=>{
              alert(error);
        });

            }
      validateForm(){
              let fields = this.state.fields;
                    let errors = {};
                    let formIsValid = true;
              
                    if (!fields["employeeNmae"]) {
                      formIsValid = false;
                      errors["employeeName"] = "*Please enter your Full Name.";
                    }
              
                    if (typeof fields["employeeName"] !== "undefined") {
                      if (!fields["employeeName"].match(/^[a-zA-Z ]*$/)) {
                        formIsValid = false;
                        errors["employeeName"] = "*Please enter alphabet characters only.";
                      }
                    }
              
                   
              
                    if (!fields["employeeId"]) {
                      formIsValid = false;
                      errors["employeeId"] = "*Please enter Employee ID";
                    }
              
                    if (typeof fields["employeeId"] !== "undefined") {
                      if (!fields["employeeId"].match(/^[0-9]{10}$/)) {
                        formIsValid = false;
                        errors["employeeId"] = "*Please enter valid Employee ID.";
                      }
                    }
              
              
              
                    if (!fields["employeeEmailId"]) {
                      formIsValid = false;
                      errors["employeeEmailId"] = "*Please enter your Email-ID.";
                    }
              
                    if (typeof fields["employeeEmailId"] !== "undefined") {
                      //regular expression for email validation
                      var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
                      if (!pattern.test(fields["employeeEmailId"])) {
                        formIsValid = false;
                        errors["employeeEmailId"] = "*Please enter valid email-ID.";
                      }
                    }
              
                    if (!fields["mobileNo"]) {
                      formIsValid = false;
                      errors["mobileNo"] = "*Please enter your mobile no.";
                    }
              
                    if (typeof fields["mobileNo"] !== "undefined") {
                      if (!fields["mobileNo"].match(/^[0-9]{10}$/)) {
                        formIsValid = false;
                        errors["mobileNo"] = "*Please enter valid mobile no.";
                      }
                    }
              
                    if (!fields["password"]) {
                      formIsValid = false;
                      errors["password"] = "*Please enter your password.";
                    }
              
                    if (typeof fields["password"] !== "undefined") {
                      if (!fields["password"].match(/^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/)) {
                        formIsValid = false;
                        errors["password"] = "*Please enter secure and strong password.";
                      }
                    }
              
                    if (!fields["conPassword"]) {
                      formIsValid = false;
                      errors["conPassword"] = "*Please enter your password.";
                    }
              
                    if (typeof fields["conPassword"] !== "undefined") {
                      if (!fields["conPassword"].match(/^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/)) {
                        formIsValid = false;
                        errors["conPassword"] = "*Please enter secure and strong password.";
                      }

            }
  
    }
   
   
  render() {
    const{Registration}=this.state
    return (
       
                 <div class="container">
                  <div ><br></br>
                        <h2 style={{backgroundColor:"orange",margin:"1px",textAlign:"center",padding:"1px",marginBottom:"20px",width:"100%"}}class="pt-3 font-weight-bold">
                          Employee Registration</h2>
                    </div>
                  <div class="panel-body p-3">  

                  <div > 
                   <table  class="panel border bg-green" border={10} width="45%" align='center'>
           
            <tr>
            
               <th >Employee Id</th>
               <th>
               
                <input class="far fa-user p-2" placeholder='Employee-ID' required type="text" name="employeeId"
                 onChange={(e)=>this.handleChange({employeeId:e.target.value})}></input><br></br>
                </th>
               </tr>
                <tr>

                <th> Full Name</th>
                <th>
               <input class="far fa-user p-2"   placeholder='Full Name' required type="text" name="employeeName"
                onChange={(e)=>this.handleChange({employeeName:e.target.value})}></input>
                <div className="errorMsg">{this.state.errors.employeeName}</div>
               </th>

                </tr>
                
                <tr>
                <th>Email Id </th>
                <th>
               <input class="far fa-user p-2"  placeholder='Email-ID' required type="text" name="employeeEmailId"
                onChange={(e)=>this.handleChange({employeeEmailId:e.target.value})}></input>
               </th>
                </tr>
                <tr>
                <th>Mobile Number </th>
                <th>
               <input class="far fa-user p-2"  placeholder='Mobile-No' required type="text" name="mobileNo"
                onChange={(e)=>this.handleChange({mobileNo:e.target.value})}></input>
               </th>
                </tr>
               
                <tr>
                <th>Password </th>
                <th>
               <input class="far fa-user p-2"  placeholder='Password' required type="password" name="password"
                onChange={(e)=>this.handleChange({password:e.target.value})}></input>
               </th>
                </tr>
                <tr>
                
                </tr>
                <tr>
                <th>Confirm Password </th>
                <th>
               <input class="far fa-user p-2"  placeholder='Confirm Password' required type="password" name="conPassword"
                onChange={(e)=>this.handleChange({conPassword:e.target.value})}></input>
               </th>
                </tr>
                <tr>
                
                </tr>
                
                <tr>
                <th>Date of Joining   </th>
                <th>
               <input  placeholder='Date of Joining' required type="Date" name="date"
                onChange={(e)=>this.handleChange({date:e.target.value})}></input>
               </th>
                </tr>
                <tr>

                <th>Department </th>
                <th>
               <input   class="far fa-user p-2" placeholder='Department' required type="text" name="department"
                onChange={(e)=>this.handleChange({department:e.target.value})}></input>
               </th>
              
                </tr>

                <tr>
                <th>Available Leave  </th>
                <th>
               <input  class="far fa-user p-2"  placeholder='Available Leave' required type="text" name="availableLeave"
               
                onChange={(e)=>this.handleChange({availableLeave:e.target.value})}></input>
               </th>
                </tr>
            <tr>
               
            </tr>

        </table>
        </div>    
        </div>
        <div>
        <button align="Center" onClick={this.newemp}>Register</button>
         
        </div>
        
      </div>

      
    )

        
    }


 

  }
