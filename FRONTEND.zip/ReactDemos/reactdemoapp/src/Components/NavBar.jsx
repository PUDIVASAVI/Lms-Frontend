NavBar.js

import logo from './logo.svg';
import './App.css';


import ListEmployee from './Components/ListEmployee';
import Login from './Login';

import LeaveDate from './Components/LeaveApplication';
import {Routes,Route,Link} from 'react-router-dom';

import GetAllLeaveApp from './GetAllLeaveApp';

import SignUp from './Components/Signup_component';
import ListManager from './Components/Manager';

import AddLeave from './Components/LeaveCreate';
import Registration from './Components/Registration';
import DashBoard from './Components/DashBoard';




function NavApp() {
  return (
    <div className="App">
      <h1>Leave Management System</h1>
{/*       
      <Routes><Route path='registration' element={<Registration/>}></Route></Routes> */}
      <Link to={'DashBoard'}>DashBoard</Link>

      <Link to={'/'}>ListEmployee </Link>
      <Link to={'/manager'}>Manager </Link>
      <Link to={'/leave'}> Leave_Datails  </Link> 
      <Link to={'/sign'}>Sign_Up </Link>
      <Link to={'/LoginManager'}>LoginManager</Link>
      <Link to={'/LeaveListComponent'}>LeaveList</Link>
      

      <Link to={'/addleave'}>Add_Leave </Link>
      <Link to={'/GetAllLeaveApp'}>GetAllLeaveApp </Link>
      <Link to={'/ShowLvDetailsById'}>ShowLvDetailsById </Link>
    
    <Routes>
      
      <Route path='/DashBoard' element={<DashBoard/>}></Route>
      <Route path='/GetAllLeaveApp' element={<GetAllLeaveApp/>}></Route>

      <Route path='/ListEmployee' element={<ListEmployee/>}></Route>
      <Route path='/manager' element={<ListManager/>}></Route>
      <Route path='/leave' element={<LeaveDate/>}></Route> 
      <Route path='/sign' element={<SignUp/>}></Route>
      <Route path='/addleave' element={<AddLeave/>}></Route>
      <Route path='/ShowLvDetailsById' element={<ShowLvDetailsById/>}></Route>
      <Route path='/LoginManager' element={<LoginManager/>}></Route>

      
    </Routes>
    </div>
  );
}

export default NavApp;

