import React from 'react';
import LeaveOperations from '../Services/LeaveOperations';

class LeaveDate extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={
            leaves:[]
        }
    }
    componentDidMount()
    {
        LeaveOperations.getLeave().then((res)=>{
            this.setState({leaves:res.data});
        })
    }
    render(){
        return(
            <div>
                <h1 className="text-center">My Details Section</h1>
                <br></br>
                <br></br>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Leave ID</th>
                                <th>Number Of Days</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>LeaveType</th>
                                <th>Status</th>
                                <th>Reason</th>
{/*                                 
                                <th>Manager Comments</th> */}
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.leaves.map(
                                    emp=>
                                    <tr key={emp.leaveId}>
                                        <td>{emp.leaveId}</td>
                                        <td>{emp.noOfDays}</td>
                                        <td>{emp.startDate}</td>
                                        <td>{emp.endDate}</td>
                                        <td>{emp.leaveType}</td>
                                        <td>{emp.status}</td>
                                        <td>{emp.reason}</td>
                                        {/* <td>{emp.managerComments}</td> */}
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>

                </div>
                <a href='/addleave'>
                    <button className='btn btn-success'>New Application</button>
                </a>
            </div>
        )
    }
}
export default LeaveDate;
