import React from 'react';

import axios from "axios";

import { Link } from 'react-router-dom';

export default class AddLeave extends React.Component

{

    constructor()

    {

        super();

        this.state={

        noOfDays:'',

        startDate:'',

        endDate:'',

        leaveType:'',

        status:'',

        reason:'',

        appliedOn:'',

        employeeId:'',

    //    ManagerComments:'',

       errors:{}

 

        }

    }

   

    changeDayHandler=(event)=>{

        this.setState({noOfDays:event.target.value});

    }

    changeSDateHandler=(event)=>{

        this.setState({startDate:event.target.value});

    }

    changeEDateHandler=(event)=>{

        this.setState({endDate:event.target.value});

    }

    changeLeaveTHandler=(event)=>{

        this.setState({leaveType:event.target.value});

    }

    // changeStatusTHandler=(event)=>{

    //     this.setState({status:event.target.value});

    // }

    changeReasonTHandler=(event)=>{

        this.setState({reason:event.target.value});

    }

    changeappliedHandler=(event)=>{

        this.setState({appliedOn:event.target.value});

    }

    changeemployeeHandler=(event)=>{

        this.setState({employeeId:event.target.value});

    }

 

    formValidation =() =>{

 

        const {noOfDays,startDate,endDate,leaveType,status, reason, appliedOn,employeeId}=this.state;

        let isValid = true;

        const errors = {};

        if(noOfDays.trim().length == 0){

            errors.noOfDays ="Please Enter NoofDays";

            isValid=false;

        }

        if(startDate.trim().length == 0){

            errors.startDate ="Please Enter Start Date";

            isValid=false;

        }

        if(endDate.trim().length == 0){

            errors.endDate ="Please Enter EndDate";

            isValid=false;

        }

        if(leaveType.trim().length == 0){

            errors.leaveType ="Please enter LeaveType";

            isValid=false;

        }

        if(status.trim().length == 0){

            errors.status ="Please Confirm the Status";

            isValid=false;

        }

        if(reason.trim().length == 0){

            errors.reason ="Please select Reason";

            isValid=false;

        }

        if(appliedOn.trim().length == 0){

            errors.appliedOn ="Please AppliedOn";

            isValid=false;

        }

        if(employeeId.trim().length == 0){

            errors.employeeId="Please Enter Employee Id.";

            isValid=false;

        // if(ManagerComments.trim().length == 0){

        //     errors.ManagerComments ="Please Enter ManagerComments";

        //     isValid=false;

        // }

       

        }

        this.setState({errors});

        console.log(isValid)

        console.log(errors)

        return isValid;

 

    }

   

    onFormSubmit =(e) =>{

        e.preventDefault();

        const isValid =this.formValidation();

        if(isValid ==true){

            this.saveLeave();

        }

 

    }

 

   

    saveLeave=(e)=>{

        // e.preventDefault();

        console.log("save employee method called")

        console.log(this.state.noOfDays,this.state.startDate,this.state.endDate,this.state.leaveType,this.state.status,this.state.reason,this.state.appliedOn,this.state.managerComments)

      const  result=axios.post('http://localhost:26924/api/Leaves',{

           "Leave ID":0,

           "NoOfDays":this.state.noOfDays,

           "StartDate":this.state.startDate,

           "EndDate":this.state.endDate,

           "LeaveType":this.state.leaveType,

           "Status":'Pending',

           "Reason":this.state.reason,

           "AppliedOn":this.state.appliedOn,

           "EmployeeId":this.state.employeeId,

           "ManagerComments":'No Comments'

           

        });

        window.location='/DashBoard';

        console.log(result);

    }

   

   

       

   

   

    render(){

       

        return(

            <div className='col-sm-6 offset-sm-3'>

                <div className='card-body'>

                    <form>

                        <div className='col-sm-6 offset-sm-3'>

                            <label>NoOfDays:</label>

                            <input className='form-control' name='Days' onChange={this.changeDayHandler} value={this.state.noOfDays}/>

                        </div>

                        <div className='col-sm-6 offset-sm-3'>

                            <label>StartDate:</label>

                            <input type="date" className='form-control' name='D1' onChange={this.changeSDateHandler} value={this.state.startDate}/>

                        </div>

                        <div className='col-sm-6 offset-sm-3'>

                            <label>EndDate:</label>

                            <input type="date" className='form-control' name='D2' onChange={this.changeEDateHandler} value={this.state.endDate}/>

                        </div>

                        <div className='col-sm-6 offset-sm-3'>

                            <label>LeaveType:</label>

                            <input className='form-control' name='D3' onChange={this.changeLeaveTHandler} value={this.state.leaveType}/>

                        </div>

                        {/* <div className='form-group'>

                            <label>Status:</label>

                            <input className='form-control' name='D4' onChange={this.changeStatusTHandler} value={this.state.status}/>

                        </div> */}

                        <div className='col-sm-6 offset-sm-3'>

                            <label>Reason:</label>

                            <input className='form-control' name='D5' onChange={this.changeReasonTHandler} value={this.state.reason}/>

                        </div>

                    <div className='col-sm-6 offset-sm-3'>

                            <label>Applied On:</label>

                            <input type='date' className='form-control' name='D6' onChange={this.changeappliedHandler} value={this.state.appliedOn}/>

                        </div>

                        <div className='col-sm-6 offset-sm-3'>

                            <label>Employee Id:</label>

                            <input className='form-control' name='D7' onChange={this.changeemployeeHandler} value={this.state.employeeId}/>

                        </div>

                        {/*}

                        <div className='form-group'>

                            <label>Manager Comments:</label>

                            <input className='form-control' name='D6' onChange={this.changeCommentTHandler} value={this.state.managerComments}/>

                        </div>

                         */}

                        <button  className='btn btn-success' onClick={this.onFormSubmit}>Apply</button>

                        {

                             Object.keys(this.state.errors).map((item)=>{

                                return <div key={item} style={{color:"red"}}>{this.state.errors[item]}</div>

                            })}

                       

                        <button className='btn btn-success' >Cancel</button>

                       

                    </form>

                </div>

            </div>

        )

    }

}  